#include <stdio.h>
#include <stdlib.h>
#include <time.h>

long int sumaEnteros(FILE * file, int size, int * array);
void numeroMasRepetido(FILE * file, int size, int * array);

int main(int argc, const char * argv[])
{

    struct timespec start;
    struct timespec end;
    double elapsed;
    clock_gettime(CLOCK_REALTIME, &start);

    FILE *file;
    file = fopen(argv[1], "r"); //abrir el archivo enviado como argumento en la terminal

    if (file == NULL) {
        printf("Error al abrir el archivo\n");
        return 1;
    }

    int size;
    int *array = NULL;

    fscanf(file, "%d", &size);
    array = (int *)malloc(size * sizeof(int));//pide memoria necesaria para el array

    long int sum = sumaEnteros(file, size, array);

    long int maxCount = 0;
    int numberMaxCount = 0;

    clock_gettime(CLOCK_REALTIME, &end);
    elapsed = (end.tv_sec - start.tv_sec)+(end.tv_nsec - start.tv_nsec);

    printf("El resultado de la suma fue: %ld\n", sum);
    printf("El promedio de valores es: %ld\n", sum/size);
    //printf("El valor que mas se repite es: %d\n", valorMasFrecuente);
    printf("El Tiempo de la suma fue es: %lf\n", elapsed);

    fclose(file);
    free(array);


    return 0;
}

long int sumaEnteros(FILE * file, int size, int * array) {
  long int sum = 0;

  for (int i = 0; i < size; i++) {
    fscanf(file, "%d", &array[i]);
    sum += array[i];
  }

  return sum;
}